from dashboard.views import dashboard
from importlib import import_module
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.contrib.staticfiles.storage import staticfiles_storage
from django.templatetags.static import static
from django.urls import path, include
from django.views.generic import RedirectView

from django.conf import settings
from django.conf.urls.static import static

from leases.views import UnitAutocomplete
from core.views import SettingsView


def plain_include(module_path):
    return include(import_module(module_path).urlpatterns)


# -----------------------------
# Namespaced App URLs
# -----------------------------
app_patterns = [
    path('', include('core.urls')),

    path('', include(('dashboard.urls', 'dashboard'),
         namespace='dashboard')),

    path(
        "favicon.ico",
        RedirectView.as_view(
            url=staticfiles_storage.url("images/favicon.ico"),
            permanent=True,
        ),
    ),

    path('tenants/', include(
        ('tenants.urls', 'tenants'),
        namespace='tenants'
    )),

    path('payments/', include(
        ('payments.urls', 'payments'),
        namespace='payments'
    )),

    path('expenses/', include(
        ('expenses.urls', 'expenses'),
        namespace='expenses'
    )),

    path('documents/', include(
        ('documents.urls', 'documents'),
        namespace='documents'
    )),

    path('notifications/', include(
        ('notifications.urls', 'notifications'),
        namespace='notifications'
    )),

    path('reports/', include(
        ('reports.urls', 'reports'),
        namespace='reports'
    )),

    path('utilities/', include('utilities.urls')),

    path('properties/', include(
        ('properties.urls', 'properties'),
        namespace='properties'
    )),

    path('accounts/', include(
        ('accounts.urls', 'accounts'),
        namespace='accounts'
    )),

    path('leases/', include('leases.urls')),

    path('invoices/', include(
        ('invoices.urls', 'invoices'),
        namespace='invoices'
    )),

    path('maintenance/', include(
        ('maintenance.urls', 'maintenance'),
        namespace='maintenance'
    )),

    path(
        'unit-autocomplete/',
        UnitAutocomplete.as_view(),
        name='unit-autocomplete'
    ),

    path("smart-meter/", include("smart_meter.urls")),
    path("api/", include("leases.urls_pcr")),

    path("accounts/", include("accounts.urls")),
    path("accounts/", include("django.contrib.auth.urls")),
]


# Root compatibility URLs are intentionally not namespaced. Namespaced reversing
# should use the production-compatible `/tms/` URL tree below.
root_app_patterns = [
    path('', plain_include('core.urls')),
    path('', plain_include('dashboard.urls')),

    path(
        "favicon.ico",
        RedirectView.as_view(
            url=staticfiles_storage.url("images/favicon.ico"),
            permanent=True,
        ),
    ),

    path('tenants/', plain_include('tenants.urls')),
    path('payments/', plain_include('payments.urls')),
    path('expenses/', plain_include('expenses.urls')),
    path('documents/', plain_include('documents.urls')),
    path('notifications/', plain_include('notifications.urls')),
    path('reports/', plain_include('reports.urls')),
    path('utilities/', plain_include('utilities.urls')),
    path('properties/', plain_include('properties.urls')),
    path('accounts/', plain_include('accounts.urls')),
    path('leases/', plain_include('leases.urls')),
    path('invoices/', plain_include('invoices.urls')),
    path('maintenance/', plain_include('maintenance.urls')),

    path(
        'unit-autocomplete/',
        UnitAutocomplete.as_view(),
        name='unit-autocomplete'
    ),

    path("smart-meter/", plain_include("smart_meter.urls")),
    path("api/", plain_include("leases.urls_pcr")),

    path("accounts/", plain_include("accounts.urls")),
    path("accounts/", include("django.contrib.auth.urls")),
]


urlpatterns = [
    path('admin/', admin.site.urls),

    # Login / Logout
    path(
        'login/',
        auth_views.LoginView.as_view(
            template_name='login.html'
        ),
        name='login'
    ),

    path(
        'logout/',
        auth_views.LogoutView.as_view(),
        name='logout'
    ),

    # Password Reset URLs
    path(
        'accounts/password_reset/',
        auth_views.PasswordResetView.as_view(
            template_name='accounts/password_reset.html'
        ),
        name='password_reset'
    ),

    path(
        'accounts/password_reset/done/',
        auth_views.PasswordResetDoneView.as_view(
            template_name='accounts/password_reset_done.html'
        ),
        name='password_reset_done'
    ),

    path(
        'accounts/reset/<uidb64>/<token>/',
        auth_views.PasswordResetConfirmView.as_view(
            template_name='accounts/password_reset_confirm.html'
        ),
        name='password_reset_confirm'
    ),

    path(
        'accounts/reset/done/',
        auth_views.PasswordResetCompleteView.as_view(
            template_name='accounts/password_reset_complete.html'
        ),
        name='password_reset_complete'
    ),

    # Root URLs (existing)
    *root_app_patterns,

    # Production-compatible URLs
    path('tms/', include(app_patterns)),
]


urlpatterns += static(
    settings.MEDIA_URL,
    document_root=settings.MEDIA_ROOT
)

if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL,
        document_root=settings.MEDIA_ROOT
    )

if getattr(settings, "ENABLE_LOCAL_DEBUG_TOOLBAR", False):
    urlpatterns += [
        path("__debug__/", include("debug_toolbar.urls")),
    ]
